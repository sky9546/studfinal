package com.Spring.demo.controller;


import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Spring.demo.Service.DepartmentService;
import com.Spring.demo.modal.Department;



@RestController
public class DepartmentController {

    private static final Logger logger = LogManager.getLogger(DepartmentController.class.getName());

    @Autowired
    private DepartmentService departmentService;

    // Displaying list of all departments
    @GetMapping("/departments")
    public ResponseEntity<List<Department>> getAllDepartments() {
        try {
            List<Department> departments = departmentService.getAllDepartments();
            return ResponseEntity.ok(departments);
        } catch (Exception e) {
            logger.error("Error occurred while fetching all departments: " + e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Displaying department by id
    @GetMapping("/departments/{id}")
    public ResponseEntity<Department> getDepartment(@PathVariable int id) {
        try {
            Optional<Department> department = departmentService.getDepartment(id);
            return department.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
        } catch (Exception e) {
            logger.error("Error occurred while fetching department by ID: " + e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Inserting department
    @PostMapping("/departments")
    public ResponseEntity<Void> addDepartment(@RequestBody Department department) {
        try {
            departmentService.addDepartment(department);
            return ResponseEntity.status(HttpStatus.CREATED).build();
        } catch (Exception e) {
            logger.error("Error occurred while adding department: " + e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Updating department by id
    @PutMapping("/departments/{id}")
    public ResponseEntity<Void> updateDepartment(@RequestBody Department d, @PathVariable int id) {
        try {
            departmentService.updateDepartment(d, id);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            logger.error("Error occurred while updating department by ID: " + e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Deleting all departments
    @DeleteMapping("/departments")
    public ResponseEntity<Void> deleteAllDepartments() {
        try {
            departmentService.deleteAllDepartment();
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            logger.error("Error occurred while deleting all departments: " + e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Deleting department by id
    @DeleteMapping("departments/{id}")
    public ResponseEntity<Void> deleteDepartmentByID(@PathVariable int id) {
        try {
            departmentService.deleteDepartmentByID(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            logger.error("Error occurred while deleting department by ID: " + e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Updating/patching department by id
    @PatchMapping("departments/{id}")
    public ResponseEntity<Void> patchDepartmentByID(@RequestBody Department d, @PathVariable int id) {
        try {
            departmentService.patchDepartment(d, id);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            logger.error("Error occurred while patching department by ID: " + e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
