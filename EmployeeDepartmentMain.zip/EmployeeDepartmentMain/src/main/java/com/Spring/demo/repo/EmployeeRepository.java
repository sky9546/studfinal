package com.Spring.demo.repo;

import org.springframework.data.repository.CrudRepository;

import com.Spring.demo.modal.Employee;



// interface extending crud repository
public interface EmployeeRepository extends CrudRepository<Employee, Integer>{
	
}
