package com.Spring.demo.repo;

import org.springframework.data.repository.CrudRepository;

import com.Spring.demo.modal.Department;


public interface DepartmentRepository extends CrudRepository<Department, Integer>{

}
