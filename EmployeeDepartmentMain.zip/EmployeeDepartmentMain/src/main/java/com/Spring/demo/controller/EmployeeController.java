package com.Spring.demo.controller;

import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Spring.demo.Service.EmployeeService;
import com.Spring.demo.modal.Employee;


@RestController
public class EmployeeController {

    private static final Logger logger = LogManager.getLogger(EmployeeController.class.getName());

    @Autowired
    private EmployeeService employeeService;

    // Displaying list of all employees
    @GetMapping("/employees")
    public ResponseEntity<List<Employee>> getAllEmployees() {
        try {
            List<Employee> employees = employeeService.getAllEmployees();
            return ResponseEntity.ok(employees);
        } catch (Exception e) {
            logger.error("Error occurred while fetching all employees: " + e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Displaying employee by id
    @GetMapping("/employees/{id}")
    public ResponseEntity<Employee> getEmployee(@PathVariable int id) {
        try {
            Optional<Employee> employee = employeeService.getEmployee(id);
            return employee.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
        } catch (Exception e) {
            logger.error("Error occurred while fetching employee by ID: " + e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Inserting employee
    @PostMapping("/employees")
    public ResponseEntity<Void> addEmployee(@RequestBody Employee employee) {
        try {
            employeeService.addEmployee(employee);
            return ResponseEntity.status(HttpStatus.CREATED).build();
        } catch (Exception e) {
            logger.error("Error occurred while adding employee: " + e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Updating employee by id
    @PutMapping("/employees/{id}")
    public ResponseEntity<Void> updateEmployee(@RequestBody Employee e, @PathVariable int id) {
        try {
            employeeService.updateEmployee(e, id);
            return ResponseEntity.ok().build();
        } catch (Exception e1) {
            logger.error("Error occurred while updating employee by ID: " + e1.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Deleting all employees
    @DeleteMapping("/employees")
    public ResponseEntity<Void> deleteAllEmployees() {
        try {
            employeeService.deleteAllEmployees();
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            logger.error("Error occurred while deleting all employees: " + e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Deleting employee by id
    @DeleteMapping("employees/{id}")
    public ResponseEntity<Void> deleteEmployeeByID(@PathVariable int id) {
        try {
            employeeService.deleteEmployeeByID(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            logger.error("Error occurred while deleting employee by ID: " + e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Updating/patching employee by id
    @PatchMapping("employees/{id}")
    public ResponseEntity<Void> patchEmployeeByID(@RequestBody Employee e, @PathVariable int id) {
        try {
            employeeService.patchEmployee(e, id);
            return ResponseEntity.ok().build();
        } catch (Exception e1) {
            logger.error("Error occurred while patching employee by ID: " + e1.getMessage(), e1);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
